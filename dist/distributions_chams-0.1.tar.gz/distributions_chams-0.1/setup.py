from setuptools import setup

setup(name='distributions_chams',
      version='0.1',
      description='Gaussian distributions_chams',
      packages=['distributions_chams'],
      author='Chams Rutkowski',
      author_email='chams.rut@gmail.com',
      zip_safe=False)
